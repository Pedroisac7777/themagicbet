import React from 'react';
import { useNavigate } from 'react-router-dom';
import MatrixRain from '../components/MatrixRain';
import Countdown from '../components/Countdown';
import { ShieldCheck, Cpu, BarChart3, ExternalLink } from 'lucide-react';
import NeonButton from '../components/NeonButton';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();
  
  const handleCTAClick = () => {
    navigate('/auth');
  };
  
  const openRubyXLink = (e: React.MouseEvent, path: string = '') => {
    e.preventDefault();
    window.open(`https://rubyx.com.br${path}`, '_blank');
  };
  
  return (
    <div className="relative min-h-screen bg-black text-white overflow-x-hidden">
      <MatrixRain />
      
      {/* Header */}
      <header className="py-6 px-6 relative z-10">
        <h1 className="text-3xl font-bold text-primary">Magic Bet</h1>
      </header>
      
      {/* Hero Section */}
      <main className="container mx-auto px-4 py-10 relative z-10">
        <div className="text-center max-w-4xl mx-auto mb-16">
          <h1 className="text-4xl md:text-5xl xl:text-6xl font-bold mb-6 text-white leading-tight">
            Maximize seus Ganhos com Sinais Exclusivos para Slots da <a 
              href="https://rubyx.com.br" 
              onClick={(e) => openRubyXLink(e)} 
              className="text-primary hover:underline inline-flex items-center"
              target="_blank"
              rel="noopener noreferrer"
            >
              RubyX <ExternalLink size={20} className="ml-1" />
            </a>
          </h1>
          <p className="text-xl md:text-2xl mb-12 text-white/80 max-w-3xl mx-auto">
            Descubra os horários estratégicos para jogar e multiplique suas chances de vitória com nosso algoritmo avançado.
          </p>
          
          {/* Countdown & Spots */}
          <div className="flex flex-col md:flex-row justify-center items-center gap-6 mb-12 p-6 rounded-lg bg-black/40 backdrop-blur-sm border border-primary/30 shadow-sm">
            <Countdown />
            <div className="text-xl font-bold text-yellow-400 flex items-center">
              <span className="animate-pulse mr-2">⚠️</span> 
              <span>Apenas <span className="text-yellow-300">22</span> vagas restantes.</span>
            </div>
          </div>
          
          {/* CTA Button */}
          <NeonButton
            onClick={handleCTAClick}
            neonColor="green"
            className="text-xl font-bold py-5 px-10 hover:scale-105 mx-auto"
          >
            ACESSAR PAINEL EXCLUSIVO
          </NeonButton>
          
          {/* Slots List */}
          <div className="mt-12 bg-black/50 p-6 rounded-lg backdrop-blur-sm border border-primary/20 shadow-sm">
            <h3 className="text-xl mb-6 font-medium text-primary">Slots Disponíveis na <a 
              href="https://rubyx.com.br" 
              onClick={(e) => openRubyXLink(e)} 
              className="hover:underline inline-flex items-center"
              target="_blank"
              rel="noopener noreferrer"
            >
              RubyX <ExternalLink size={16} className="ml-1" />
            </a>:</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {[
                "Fortune Tiger",
                "Fortune Dragon",
                "Fortune Rabbit",
                "Fortune Ox",
                "Wild Ape",
                "Gates of Olympus 1000"
              ].map((slot) => (
                <div key={slot} className="bg-black/70 p-4 rounded-md border border-primary/30 hover:border-primary/60 transition-all duration-300 hover:shadow-sm transform hover:-translate-y-1">
                  {slot}
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Why Magic Bet Section */}
        <section className="py-16 bg-black/30 backdrop-blur-sm rounded-lg border border-primary/10 mb-16">
          <h2 className="text-3xl font-bold mb-12 text-center text-white">Por Que Magic Bet?</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto px-4">
            <div className="bg-black/60 p-8 rounded-lg border border-primary/30 hover:border-primary/60 transition-all duration-300 hover:shadow-sm transform hover:-translate-y-1">
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-6 border border-primary/30">
                  <Cpu className="text-primary w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-4">Análise Inteligente</h3>
                <p className="text-white/70">Nossa tecnologia proprietária detecta padrões de pagamentos e timing ideal para maximizar seus resultados.</p>
              </div>
            </div>
            <div className="bg-black/60 p-8 rounded-lg border border-primary/30 hover:border-primary/60 transition-all duration-300 hover:shadow-sm transform hover:-translate-y-1">
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-6 border border-primary/30">
                  <BarChart3 className="text-primary w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-4">Sinais Precisos</h3>
                <p className="text-white/70">Receba instruções detalhadas sobre horário exato, número de rodadas e estratégia de jogo.</p>
              </div>
            </div>
            <div className="bg-black/60 p-8 rounded-lg border border-primary/30 hover:border-primary/60 transition-all duration-300 hover:shadow-sm transform hover:-translate-y-1">
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-6 border border-primary/30">
                  <ShieldCheck className="text-primary w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-4">Integração RubyX</h3>
                <p className="text-white/70">Sistema integrado diretamente com a API da RubyX para garantir compatibilidade e resultados otimizados.</p>
              </div>
            </div>
          </div>
        </section>
        
        {/* What You Get Section */}
        <section className="py-16">
          <h2 className="text-3xl font-bold mb-12 text-center text-white">O Que Você Ganha</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto px-4">
            <div className="bg-black/40 backdrop-blur-sm p-8 rounded-lg border border-accent/20 hover:border-accent/40 transition-all duration-300 hover:shadow-sm text-center transform hover:-translate-y-1">
              <div className="text-5xl mb-6 flex justify-center">
                <div className="w-20 h-20 rounded-full bg-accent/10 flex items-center justify-center border border-accent/30">🔍</div>
              </div>
              <h3 className="text-xl font-bold mb-2 text-accent">Painel privado em tempo real</h3>
            </div>
            <div className="bg-black/40 backdrop-blur-sm p-8 rounded-lg border border-accent/20 hover:border-accent/40 transition-all duration-300 hover:shadow-sm text-center transform hover:-translate-y-1">
              <div className="text-5xl mb-6 flex justify-center">
                <div className="w-20 h-20 rounded-full bg-accent/10 flex items-center justify-center border border-accent/30">💰</div>
              </div>
              <h3 className="text-xl font-bold mb-2 text-accent">Bônus exclusivo na <a 
                href="https://rubyx.com.br" 
                onClick={(e) => openRubyXLink(e)} 
                className="hover:underline inline-flex items-center"
                target="_blank"
                rel="noopener noreferrer"
              >RubyX <ExternalLink size={14} className="ml-1" /></a></h3>
            </div>
            <div className="bg-black/40 backdrop-blur-sm p-8 rounded-lg border border-accent/20 hover:border-accent/40 transition-all duration-300 hover:shadow-sm text-center transform hover:-translate-y-1">
              <div className="text-5xl mb-6 flex justify-center">
                <div className="w-20 h-20 rounded-full bg-accent/10 flex items-center justify-center border border-accent/30">🔌</div>
              </div>
              <h3 className="text-xl font-bold mb-2 text-accent">Acesso à nossa API integrada com <a 
                href="https://rubyx.com.br" 
                onClick={(e) => openRubyXLink(e)} 
                className="hover:underline inline-flex items-center"
                target="_blank"
                rel="noopener noreferrer"
              >RubyX <ExternalLink size={14} className="ml-1" /></a></h3>
            </div>
          </div>
        </section>
        
        {/* Testimonials */}
        <section className="py-16">
          <h2 className="text-3xl font-bold mb-12 text-center text-white">Depoimentos</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto px-4">
            <div className="bg-black/70 backdrop-blur-sm p-6 rounded-lg border border-primary/30 hover:border-primary/60 transition-all duration-300 hover:shadow-sm transform hover:-translate-y-1">
              <div className="text-sm opacity-70 mb-3 text-primary/50">/* Usuário #001 */</div>
              <p className="mb-4 text-white/90">
                "Em menos de 15 minutos no Magic Bet já vi meus primeiros ganhos — incrível!"
              </p>
              <div className="text-sm opacity-70 text-primary/50">— Lucas R., São Paulo</div>
            </div>
            <div className="bg-black/70 backdrop-blur-sm p-6 rounded-lg border border-primary/30 hover:border-primary/60 transition-all duration-300 hover:shadow-sm transform hover:-translate-y-1">
              <div className="text-sm opacity-70 mb-3 text-primary/50">/* Usuário #002 */</div>
              <p className="mb-4 text-white/90">
                "Sinais precisos e painel intuitivo. Me senti um hacker de verdade!"
              </p>
              <div className="text-sm opacity-70 text-primary/50">— Marina S., Rio de Janeiro</div>
            </div>
            <div className="bg-black/70 backdrop-blur-sm p-6 rounded-lg border border-primary/30 hover:border-primary/60 transition-all duration-300 hover:shadow-sm transform hover:-translate-y-1">
              <div className="text-sm opacity-70 mb-3 text-primary/50">/* Usuário #003 */</div>
              <p className="mb-4 text-white/90">
                "Ferramenta top! Lucros reais desde o primeiro uso, recomendo demais."
              </p>
              <div className="text-sm opacity-70 text-primary/50">— Pedro A., Belo Horizonte</div>
            </div>
          </div>
        </section>
      </main>
      
      {/* Footer */}
      <footer className="bg-black/90 py-10 mt-10 border-t border-primary/20 relative z-10">
        <div className="container mx-auto px-4">
          <div className="text-xs md:text-sm mb-8 bg-black/80 p-4 rounded-md border border-primary/30 max-w-2xl mx-auto">
            <div><span className="text-primary mr-2">{'>'}</span> Exclusivo para usuários da plataforma <a 
              href="https://rubyx.com.br" 
              onClick={(e) => openRubyXLink(e)} 
              className="text-primary hover:underline inline-flex items-center"
              target="_blank"
              rel="noopener noreferrer"
            >RubyX <ExternalLink size={12} className="ml-1" /></a></div>
            <div><span className="text-primary mr-2">{'>'}</span> Sistema integrado via API oficial</div>
            <div><span className="text-primary mr-2">{'>'}</span> Algoritmo otimizado para máxima conversão</div>
          </div>
          <div className="flex flex-col md:flex-row justify-between items-center max-w-5xl mx-auto">
            <div className="mb-6 md:mb-0">
              <span className="text-accent">© 2025 Magic Bet</span>
            </div>
            <div className="flex space-x-6">
              <a href="#" className="text-primary hover:text-primary/80 transition-colors duration-300 hover:underline text-sm">Termos</a>
              <a href="#" className="text-primary hover:text-primary/80 transition-colors duration-300 hover:underline text-sm">Privacidade</a>
              <a href="#" className="text-primary hover:text-primary/80 transition-colors duration-300 hover:underline text-sm">Contato</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
