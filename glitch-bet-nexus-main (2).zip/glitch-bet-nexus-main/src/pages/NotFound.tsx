
import React from 'react';
import { Link } from 'react-router-dom';
import MatrixRain from '../components/MatrixRain';
import NeonButton from '../components/NeonButton';
import { HomeIcon } from 'lucide-react';

const NotFound: React.FC = () => {
  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center relative overflow-hidden">
      <MatrixRain />
      
      <div className="terminal z-10 p-8 max-w-lg w-full text-center bg-black/80 border border-neon-purple rounded-md shadow-[0_0_20px_rgba(187,0,255,0.3)] backdrop-blur-sm">
        <div className="terminal-header flex items-center gap-2 mb-6 pb-2 border-b border-neon-purple/30">
          <div className="w-3 h-3 rounded-full bg-red-500"></div>
          <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
          <div className="w-3 h-3 rounded-full bg-green-500"></div>
          <div className="flex-1 text-center text-xs text-neon-purple/70 font-code">ERROR_404</div>
        </div>
      
        <h1 className="text-6xl font-code mb-6 neon-text-purple">404</h1>
        <p className="text-xl mb-8 font-code text-white/80">Acesso negado. Página não encontrada.</p>
        
        <div className="terminal text-left mb-8 text-sm font-code bg-black/50 p-4 rounded border border-neon-purple/30">
          <div className="mb-1"><span className="text-neon-purple mr-2">{'>'}</span> Erro de autenticação</div>
          <div className="mb-1"><span className="text-neon-purple mr-2">{'>'}</span> Acesso restrito</div>
          <div className="mb-1"><span className="text-neon-purple mr-2">{'>'}</span> Verificando rotas alternativas...</div>
          <div><span className="text-neon-purple mr-2">{'>'}</span> Redirecionando para rota segura...</div>
        </div>
        
        <Link to="/">
          <NeonButton 
            neonColor="purple"
            className="mx-auto font-code"
          >
            <HomeIcon size={16} className="mr-2" />
            Voltar para o Início
          </NeonButton>
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
