
// Simple authentication service to validate the secret key
export const AUTH_SECRET_KEY = '0131020';

// Check if the user is authenticated by checking local storage
export const isAuthenticated = (): boolean => {
  return localStorage.getItem('auth_key') === AUTH_SECRET_KEY;
};

// Authenticate the user with the provided key
export const authenticate = (key: string): boolean => {
  if (key === AUTH_SECRET_KEY) {
    localStorage.setItem('auth_key', key);
    return true;
  }
  return false;
};

// Logout the user
export const logout = (): void => {
  localStorage.removeItem('auth_key');
};
