
import React from 'react';

interface TerminalLinesProps {
  lines: string[];
}

const TerminalLines: React.FC<TerminalLinesProps> = ({ lines }) => {
  return (
    <div className="mb-3 text-xs text-neon-green/30 space-y-1 border-l-2 border-neon-green/20 pl-2">
      {lines.map((line, idx) => (
        <div key={idx} className="font-code flex">
          <span className="text-neon-green/40 mr-2">[{(Math.random() * 9999).toFixed(0).padStart(4, '0')}]</span>
          <span>{line}</span>
        </div>
      ))}
    </div>
  );
};

export default TerminalLines;
