
import React from 'react';

interface TerminalHeaderProps {
  className?: string;
}

const TerminalHeader: React.FC<TerminalHeaderProps> = ({ className = "" }) => {
  return (
    <div className={`terminal-header flex items-center gap-2 mb-4 pb-2 border-b border-neon-green/40 ${className}`}>
      <div className="w-3 h-3 rounded-full bg-red-500"></div>
      <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
      <div className="w-3 h-3 rounded-full bg-green-500"></div>
      <div className="flex-1 text-center text-xs text-neon-green font-code tracking-wider">MGC_BT_TERMINAL_V3.2</div>
      <div className="text-xs text-neon-green/50 font-code">[ENCRYPTED]</div>
    </div>
  );
};

export default TerminalHeader;
